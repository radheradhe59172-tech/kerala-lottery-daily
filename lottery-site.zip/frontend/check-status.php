<?php include('../backend/db.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Check Ticket Status</title>
</head>
<body>
<h1>Check Your Ticket</h1>
<form method="GET">
    Ticket ID: <input type="text" name="ticket_id" required><br>
    <button type="submit">Check Status</button>
</form>
<?php
if (isset($_GET['ticket_id'])) {
    $id = intval($_GET['ticket_id']);
    $result = $conn->query("SELECT * FROM tickets WHERE id=$id");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<p>Status: {$row['status']}</p>";
    } else {
        echo "<p>No ticket found</p>";
    }
}
?>
</body>
</html>
