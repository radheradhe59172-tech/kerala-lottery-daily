<?php include('../backend/db.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Lottery Ticket Booking</title>
</head>
<body>
<h1>Book Your Lottery Ticket</h1>
<form action="../backend/save-booking.php" method="POST">
    Name: <input type="text" name="name" required><br>
    Email: <input type="email" name="email" required><br>
    <button type="submit">Book Ticket</button>
</form>
<a href="check-status.php">Check Ticket Status</a>
</body>
</html>
