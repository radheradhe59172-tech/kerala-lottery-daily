<?php include('db.php');
$name = $_POST['name'];
$email = $_POST['email'];
$sql = "INSERT INTO tickets (name, email, status) VALUES ('$name', '$email', 'Pending')";
if ($conn->query($sql) === TRUE) {
    echo "Ticket booked! Your Ticket ID: " . $conn->insert_id;
} else {
    echo "Error: " . $conn->error;
}
?>